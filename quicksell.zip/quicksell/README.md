# QuickSell - Online Waste Product Selling Platform

Sell-only website. Sellers product add pannalam, users browse panni seller-a contact pannalam. Buy / payment illa.

## Run panra vidham
1. Node.js and MongoDB (service run aagittu irukkanum) install pannirukkanum.
2. Project folder-la Command Prompt open pannunga:
       npm install
       npm start
3. Browser-la open pannunga: http://localhost:3000

## Folder
    server.js          Backend (Express + MongoDB + image upload)
    .env               MongoDB address and port
    public/index.html  Website page
    public/style.css   Design
    public/script.js   Frontend logic
    uploads/           Product images inge save aagum

## API
    POST /api/products   Product add
    GET  /api/products   Products list (?search= & ?category=)
